/**
* Once Upon the time Harry Potter lived in a json feed at amazon aws ...
* the Escazu Witch wants to frozen him within a nokia thing ...
*
*           _            _.,----,
* __  _.-._ / '-.        -  ,._  \)
*|  `-)_   '-.   \       / < _ )/" }
**__    '-.   \   '-, ___(c-(8)=(8)
* , `'.    `._ '.  _,'   >\    "  )
* :;;,,'-._   '---' (  ( "/`. -='/
*;:;;:;;,  '..__    ,`-.`)'- '--'
*;';:;;;;;'-._ /'._|   Y/   _/' \
*      '''"._ F    |  _/ _.'._   `\
*             L    \   \/     '._  \
*
*      .-,-,_ |     `.  `'---,  \_ _|
*      //    'L    /  \,   ("--',=`)7
*     | `._       : _,  \  /'`-._L,_'-._
*     '--' '-.\__/ _L   .`'         './/
*                 [ (  /
*                  ) `{
*      ....        \__)
* @author Rolando <rgarro@gmail.com>
*/
var deCoding = (function(){

  function deCoding(){
    //this.feedUrl = "http://de-coding-test.s3.amazonaws.com/books.json";
    this.feedUrl = "books.json";
    this.currenFeed = 0;
    this.feedData;
    this.displayHtml = "";
    this.container = "#contenContainer";
  }

  deCoding.prototype.loadData = function(){
    $.ajax({
      url:this.feedUrl,
      type:"GET",
      dataType:"json",
      success:(function(data){
          this.buildDisplay(data);
      }).bind(this)
    });
  }

  deCoding.prototype.buildDisplay = function(data){
    this.feedData = data;
    this.buildLine();
  }

  deCoding.prototype.buildLine = function(){
    if(this.currenFeed < this.feedData.length){
      var current = this.feedData[this.currenFeed];
      this.displayHtml += "<li><img src='" + current.imageURL + "'/><small>" + current.title + "</small></li>";
      this.currenFeed ++;
      this.buildLine();
    }else{
      $(this.container).html(this.displayHtml);
    }
  }

  return deCoding;
})();
