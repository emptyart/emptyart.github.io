var sky = {
		
};