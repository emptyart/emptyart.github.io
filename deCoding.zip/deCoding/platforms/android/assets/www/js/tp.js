/**
 * TP Game Hash 
 *
 *          .-""-.
 *         |[] _ _\
 *        _|_o_LII|_
 *       / | ==== | \
 *       |_| ==== |_|
 *        ||" ||  ||
 *        ||L9  o ||
 *        ||'----'||
 *      /__|    |__\
 * 
 *  
 * @author Rolando <rolando@emptyart.xyz>
 * @copyright emptyart.xyz 2016
 */
var tp = {
		init:function(){
			
		}
};