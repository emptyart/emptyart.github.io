describe("tp",function(){

	it("should have init method",function(){
        expect(tp.init).toBeFunction();
    });
	
    it("should be testable",function(){
        expect(true).toBeTrue();
    });

});