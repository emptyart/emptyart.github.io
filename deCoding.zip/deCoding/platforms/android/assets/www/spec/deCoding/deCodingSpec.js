describe("deCoding",function(){

  var deCoder;

  beforeAll(function(){
    deCoder = new deCoding();
  });

  it("should Have feedUrl property",function(){
		expect(typeof deCoder.feedUrl == "string").toBe(true);
	});

	it("feed property Should be valid url",function(){
		 expect(deCoder.feedUrl).toMatch(/(http|https):\/\/(\w+:{0,1}\w*)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%!\-\/]))?/);
	});

  it("should Have loadData method",function(){
    expect(deCoder).toHaveMethod("loadData");
  });

  it("should Have buildDisplay method",function(){
    expect(deCoder).toHaveMethod("buildDisplay");
  });

});
